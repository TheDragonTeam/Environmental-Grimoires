#Guide-API [![Build Status](http://tehnut.info/jenkins/buildStatus/icon?job=Guide-API)](http://tehnut.info/jenkins/job/Guide-API/)

Library mod for easy creation of guide books.
