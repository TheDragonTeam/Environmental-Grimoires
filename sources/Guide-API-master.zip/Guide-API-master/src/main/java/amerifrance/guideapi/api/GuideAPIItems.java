package amerifrance.guideapi.api;

import net.minecraft.item.Item;

public class GuideAPIItems {
    /**
     * The item corresponding to the Guide-API books. Access it after the Pre-Init event.
     */
    public static Item guideBook;
}
