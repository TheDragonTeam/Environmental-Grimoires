@API(owner = "guideapi", apiVersion = "@VERSION@", provides = "Guide-API|API")
package amerifrance.guideapi.api;

import cpw.mods.fml.common.API;