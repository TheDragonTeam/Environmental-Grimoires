# TheDragonLib (TDL)

[![](http://cf.way2muchnoise.eu/full_thedragonlib_downloads.svg)](http://minecraft.curseforge.com/projects/thedragonlib)
[![](http://cf.way2muchnoise.eu/versions/thedragonlib.svg)](http://minecraft.curseforge.com/projects/thedragonlib)

## About this Mod

TheDragonLib is a mod created by **[sokratis12GR](http://ftb.gamepedia.com/sokratis12GR)** **(TheDragonTeam)**.
TheDragonLib is a librally used by all (most) of TheDragonTeam's mods.

## Download

[Grab the latest publicly avaialbe versions from curseforge.](https://minecraft.curseforge.com/projects/thedragonlib/files)

[Or you can get a version from dev builds](http://fdn.redstone.tech/TheDragonTeam/thedragonlib/jars/)

## Licence

TheDragonLib is licensed under the LGPLv3 license. Full license is in [LICENSE](https://github.com/TheDragonTeam/TheDragonLib/blob/master/LICENSE).
