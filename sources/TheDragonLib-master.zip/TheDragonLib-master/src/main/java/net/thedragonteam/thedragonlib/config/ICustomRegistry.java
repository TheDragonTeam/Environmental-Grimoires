package net.thedragonteam.thedragonlib.config;

public interface ICustomRegistry {
    void registerFeature(Feature feature);
}