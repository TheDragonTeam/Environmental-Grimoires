package net.thedragonteam.thedragonlib.config;

public interface IRegisterMyOwnTiles {
    void registerTiles(String modidPrefix, String blockName);
}