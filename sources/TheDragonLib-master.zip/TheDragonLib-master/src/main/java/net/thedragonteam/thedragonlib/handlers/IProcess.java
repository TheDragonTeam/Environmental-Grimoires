package net.thedragonteam.thedragonlib.handlers;

public interface IProcess {

    void updateProcess();

    boolean isDead();
}