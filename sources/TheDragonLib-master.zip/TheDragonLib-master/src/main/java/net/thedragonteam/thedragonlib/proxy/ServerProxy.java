package net.thedragonteam.thedragonlib.proxy;

/**
 * TheDragonLib created by sokratis12GR
 * - TheDragonTeam
 */
public class ServerProxy extends CommonProxy {
}
